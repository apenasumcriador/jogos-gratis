
const jogos = [
  {
    titulo: "Cobrinha Clássica",
    imagem: "https://via.placeholder.com/200x120?text=Cobrinha",
    link: "https://playsnake.org/",
    categoria: "Clássicos"
  },
  {
    titulo: "Tetris Online",
    imagem: "https://via.placeholder.com/200x120?text=Tetris",
    link: "https://tetris.com/play-tetris",
    categoria: "Puzzle"
  },
  {
    titulo: "Pac-Man",
    imagem: "https://via.placeholder.com/200x120?text=Pac-Man",
    link: "https://www.google.com/search?q=play+pacman",
    categoria: "Arcade"
  }
];

const categorias = ["Ação", "Puzzle", "Arcade", "Clássicos", "Corrida", "Estratégia"];
const main = document.getElementById("main-content");

function renderizarJogos(filtro = "") {
  main.innerHTML = "";
  categorias.forEach(cat => {
    const jogosFiltrados = jogos.filter(j =>
      j.categoria === cat &&
      j.titulo.toLowerCase().includes(filtro.toLowerCase())
    );
    if (jogosFiltrados.length === 0) return;

    const secao = document.createElement("section");
    secao.className = "category";
    secao.innerHTML = `<h2>${cat}</h2><div class="games-container"></div>`;
    const container = secao.querySelector(".games-container");

    jogosFiltrados.forEach(jogo => {
      const card = document.createElement("div");
      card.className = "game-card";
      card.innerHTML = `
        <img src="${jogo.imagem}" alt="${jogo.titulo}">
        <h3>${jogo.titulo}</h3>
        <a href="${jogo.link}" target="_blank">Jogar</a>
      `;
      container.appendChild(card);
    });

    main.appendChild(secao);
  });
}

document.getElementById("searchBar").addEventListener("input", e => {
  renderizarJogos(e.target.value);
});

renderizarJogos();
